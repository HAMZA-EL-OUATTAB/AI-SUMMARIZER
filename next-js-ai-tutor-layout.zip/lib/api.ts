// API Client for AI Tutor Backend
// Base URL configuration - update based on environment

const API_BASE_URL = process.env.NEXT_PUBLIC_API_BASE_URL || "http://localhost:8000"

// ==================== Types & Interfaces ====================

export interface CreateChatRequest {
  title: string
}

export interface CreateChatResponse {
  session_id: string
  title: string
  created_at: string
}

export interface Message {
  id: string
  session_id: string
  role: "user" | "assistant"
  content: string
  timestamp: string
}

export interface GetMessagesResponse {
  messages: Message[]
}

export interface SendMessageRequest {
  content: string
}

export interface SendMessageResponse {
  message: Message
  ai_response: Message
}

export interface UploadFileResponse {
  file_id: string
  filename: string
  size: number
  uploaded_at: string
}

export interface ChatHistoryItem {
  session_id: string
  title: string
  created_at: string
  last_message_at: string
}

export interface ChatHistoryResponse {
  chats: ChatHistoryItem[]
}

export interface HealthCheckResponse {
  status: string
  timestamp: string
}

export interface ApiError {
  detail: string
  status: number
}

// ==================== Error Handling ====================

class ApiClientError extends Error {
  status: number
  detail: string

  constructor(status: number, detail: string) {
    super(detail)
    this.status = status
    this.detail = detail
    this.name = "ApiClientError"
  }
}

async function handleResponse<T>(response: Response): Promise<T> {
  if (!response.ok) {
    let errorDetail = "An error occurred"
    try {
      const errorData = await response.json()
      errorDetail = errorData.detail || errorData.message || errorDetail
    } catch {
      errorDetail = response.statusText || errorDetail
    }
    throw new ApiClientError(response.status, errorDetail)
  }

  const contentType = response.headers.get("content-type")
  if (contentType && contentType.includes("application/json")) {
    return response.json()
  }

  return {} as T
}

// ==================== API Client ====================

export const apiClient = {
  // ==================== Chat Endpoints ====================

  /**
   * Create a new chat session
   * POST /api/v1/chats/
   */
  async createChat(data: CreateChatRequest): Promise<CreateChatResponse> {
    const response = await fetch(`${API_BASE_URL}/api/v1/chats/`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(data),
    })
    return handleResponse<CreateChatResponse>(response)
  },

  /**
   * Get messages for a chat session
   * GET /api/v1/chats/{session_id}/messages
   */
  async getMessages(sessionId: string): Promise<GetMessagesResponse> {
    const response = await fetch(`${API_BASE_URL}/api/v1/chats/${sessionId}/messages`, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
      },
    })
    return handleResponse<GetMessagesResponse>(response)
  },

  /**
   * Send a message in a chat session
   * POST /api/v1/chats/{session_id}/messages
   */
  async sendMessage(sessionId: string, data: SendMessageRequest): Promise<SendMessageResponse> {
    const response = await fetch(`${API_BASE_URL}/api/v1/chats/${sessionId}/messages`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(data),
    })
    return handleResponse<SendMessageResponse>(response)
  },

  /**
   * Get chat history
   * GET /api/v1/chats/history
   */
  async getChatHistory(): Promise<ChatHistoryResponse> {
    const response = await fetch(`${API_BASE_URL}/api/v1/chats/history`, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
      },
    })
    return handleResponse<ChatHistoryResponse>(response)
  },

  // ==================== File Endpoints ====================

  /**
   * Upload a file to a chat session
   * POST /api/v1/files/upload/{session_id}
   */
  async uploadFile(
    sessionId: string,
    file: File,
    onProgress?: (progress: number) => void,
  ): Promise<UploadFileResponse> {
    const formData = new FormData()
    formData.append("file", file)

    return new Promise((resolve, reject) => {
      const xhr = new XMLHttpRequest()

      // Track upload progress
      if (onProgress) {
        xhr.upload.addEventListener("progress", (event) => {
          if (event.lengthComputable) {
            const progress = (event.loaded / event.total) * 100
            onProgress(progress)
          }
        })
      }

      xhr.addEventListener("load", () => {
        if (xhr.status >= 200 && xhr.status < 300) {
          try {
            const data = JSON.parse(xhr.responseText)
            resolve(data)
          } catch {
            reject(new ApiClientError(xhr.status, "Invalid JSON response"))
          }
        } else {
          let errorDetail = "Upload failed"
          try {
            const errorData = JSON.parse(xhr.responseText)
            errorDetail = errorData.detail || errorData.message || errorDetail
          } catch {
            errorDetail = xhr.statusText || errorDetail
          }
          reject(new ApiClientError(xhr.status, errorDetail))
        }
      })

      xhr.addEventListener("error", () => {
        reject(new ApiClientError(0, "Network error occurred"))
      })

      xhr.addEventListener("abort", () => {
        reject(new ApiClientError(0, "Upload aborted"))
      })

      xhr.open("POST", `${API_BASE_URL}/api/v1/files/upload/${sessionId}`)
      xhr.send(formData)
    })
  },

  // ==================== Health & Status ====================

  /**
   * Check API health
   * GET /health
   */
  async healthCheck(): Promise<HealthCheckResponse> {
    const response = await fetch(`${API_BASE_URL}/health`, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
      },
    })
    return handleResponse<HealthCheckResponse>(response)
  },

  /**
   * Root endpoint
   * GET /
   */
  async root(): Promise<{ message: string }> {
    const response = await fetch(`${API_BASE_URL}/`, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
      },
    })
    return handleResponse<{ message: string }>(response)
  },
}

// ==================== Convenience Exports ====================

export { ApiClientError }
export type { ApiError }
